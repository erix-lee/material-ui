/** @title Basic datepicker */
export declare class DatepickerOverviewExample {
}

/**
 * @title Card with multiple sections
 */
export declare class CardFancyExample {
}

/** @title Disabled datepicker */
export declare class DatepickerDisabledExample {
}

/**
 * @title Basic tabs
 */
export declare class TabsOverviewExample {
}

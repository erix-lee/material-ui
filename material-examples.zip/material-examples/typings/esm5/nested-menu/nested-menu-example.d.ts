/**
 * @title Nested menu
 */
export declare class NestedMenuExample {
}

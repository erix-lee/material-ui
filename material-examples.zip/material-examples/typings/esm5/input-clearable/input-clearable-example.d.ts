/**
 * @title Input with a clear button
 */
export declare class InputClearableExample {
    value: string;
}

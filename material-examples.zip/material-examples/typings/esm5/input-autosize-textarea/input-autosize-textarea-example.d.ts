/** @title Auto-resizing textarea */
export declare class InputAutosizeTextareaExample {
}

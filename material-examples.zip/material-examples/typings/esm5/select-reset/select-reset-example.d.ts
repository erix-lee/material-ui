/** @title Select with reset option */
export declare class SelectResetExample {
    states: string[];
}

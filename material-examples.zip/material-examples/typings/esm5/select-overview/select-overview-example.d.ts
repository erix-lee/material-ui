/**
 * @title Basic select
 */
export declare class SelectOverviewExample {
    foods: {
        value: string;
        viewValue: string;
    }[];
}

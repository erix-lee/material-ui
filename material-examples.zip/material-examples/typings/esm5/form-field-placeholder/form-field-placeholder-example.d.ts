import { FormBuilder, FormGroup } from '@angular/forms';
/** @title Form field with placeholder */
export declare class FormFieldPlaceholderExample {
    options: FormGroup;
    constructor(fb: FormBuilder);
}

/**
 * @title Configurable progress spinner
 */
export declare class ProgressSpinnerConfigurableExample {
    color: string;
    mode: string;
    value: number;
}

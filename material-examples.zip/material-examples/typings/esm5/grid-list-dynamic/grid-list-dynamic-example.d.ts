/**
 * @title Dynamic grid-list
 */
export declare class GridListDynamicExample {
    tiles: {
        text: string;
        cols: number;
        rows: number;
        color: string;
    }[];
}

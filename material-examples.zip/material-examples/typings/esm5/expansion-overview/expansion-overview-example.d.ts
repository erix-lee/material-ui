/**
 * @title Basic expansion panel
 */
export declare class ExpansionOverviewExample {
    panelOpenState: boolean;
}

/** @title Basic sidenav */
export declare class SidenavOverviewExample {
    shouldRun: boolean;
}

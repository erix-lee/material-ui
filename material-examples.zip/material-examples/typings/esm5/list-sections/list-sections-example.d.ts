/**
 * @title List with sections
 */
export declare class ListSectionsExample {
    folders: {
        name: string;
        updated: Date;
    }[];
    notes: {
        name: string;
        updated: Date;
    }[];
}

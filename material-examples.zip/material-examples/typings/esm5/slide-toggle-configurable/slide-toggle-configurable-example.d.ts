/**
 * @title Configurable slide-toggle
 */
export declare class SlideToggleConfigurableExample {
    color: string;
    checked: boolean;
    disabled: boolean;
}

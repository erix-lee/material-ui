/**
 * @title Basic slider
 */
export declare class SliderOverviewExample {
}

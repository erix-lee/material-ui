/**
 * @title Basic tooltip
 */
export declare class TooltipOverviewExample {
}

/**
 * @title Tooltip with custom position
 */
export declare class TooltipPositionExample {
    position: string;
}

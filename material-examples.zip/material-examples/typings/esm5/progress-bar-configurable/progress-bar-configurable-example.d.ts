/**
 * @title Configurable progress-bar
 */
export declare class ProgressBarConfigurableExample {
    color: string;
    mode: string;
    value: number;
    bufferValue: number;
}

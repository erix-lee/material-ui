import { MatSnackBar } from '@angular/material';
/**
 * @title Snack-bar with a custom component
 */
export declare class SnackBarComponentExample {
    snackBar: MatSnackBar;
    constructor(snackBar: MatSnackBar);
    openSnackBar(): void;
}
export declare class PizzaPartyComponent {
}

/**
 * @title Basic toolbar
 */
export declare class ToolbarOverviewExample {
}

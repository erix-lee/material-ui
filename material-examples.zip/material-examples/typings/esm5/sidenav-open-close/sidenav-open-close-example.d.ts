/** @title Sidenav open & close behavior */
export declare class SidenavOpenCloseExample {
    events: never[];
    shouldRun: boolean;
}

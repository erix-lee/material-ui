/**
 * @title Basic menu
 */
export declare class MenuOverviewExample {
}

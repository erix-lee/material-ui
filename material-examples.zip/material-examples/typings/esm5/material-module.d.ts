export declare class ExampleMaterialModule {
}

/**
 * @title Inputs with prefixes and suffixes
 */
export declare class InputPrefixSuffixExample {
}

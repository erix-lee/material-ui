import { FormControl } from '@angular/forms';
/** @title Select with multiple selection */
export declare class SelectMultipleExample {
    toppings: FormControl;
    toppingList: string[];
}

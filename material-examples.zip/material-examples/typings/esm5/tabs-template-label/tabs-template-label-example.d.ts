/**
 * @title Complex Example
 */
export declare class TabsTemplateLabelExample {
}

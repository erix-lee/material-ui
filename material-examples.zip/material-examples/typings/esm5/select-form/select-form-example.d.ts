/**
 * @title Select in a form
 */
export declare class SelectFormExample {
    selectedValue: string;
    foods: {
        value: string;
        viewValue: string;
    }[];
}

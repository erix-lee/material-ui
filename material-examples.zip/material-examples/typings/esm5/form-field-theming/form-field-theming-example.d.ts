import { FormBuilder, FormGroup } from '@angular/forms';
/** @title Form field theming */
export declare class FormFieldThemingExample {
    options: FormGroup;
    constructor(fb: FormBuilder);
    getFontSize(): number;
}

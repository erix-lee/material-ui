/** @title Form field with prefix & suffix */
export declare class FormFieldPrefixSuffixExample {
    hide: boolean;
}

/** @title Datepicker open method */
export declare class DatepickerApiExample {
}

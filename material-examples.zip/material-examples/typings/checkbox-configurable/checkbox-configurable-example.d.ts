/**
 * @title Configurable checkbox
 */
export declare class CheckboxConfigurableExample {
    checked: boolean;
    indeterminate: boolean;
    align: string;
    disabled: boolean;
}

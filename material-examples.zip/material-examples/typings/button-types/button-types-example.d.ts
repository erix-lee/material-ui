/**
 * @title Button varieties
 */
export declare class ButtonTypesExample {
}

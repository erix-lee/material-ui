/**
 * @title Basic buttons
 */
export declare class ButtonOverviewExample {
}

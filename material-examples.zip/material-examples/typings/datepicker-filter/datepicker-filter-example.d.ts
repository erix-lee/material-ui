/** @title Datepicker with filter validation */
export declare class DatepickerFilterExample {
    myFilter: (d: Date) => boolean;
}

/**
 * @title Elevation CSS classes
 */
export declare class ElevationOverviewExample {
    isActive: boolean;
}
